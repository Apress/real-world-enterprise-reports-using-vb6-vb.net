Imports System
Imports DataDynamics.ActiveReports
Imports DataDynamics.ActiveReports.Document

Public Class rptCrossTab
Inherits ActiveReport
	Public Sub New()
	MyBase.New()
		InitializeReport()
	End Sub
	#Region "ActiveReports Designer generated code"
    Private WithEvents PageHeader As PageHeader = Nothing
    Private WithEvents Detail As Detail = Nothing
    Private WithEvents PageFooter As PageFooter = Nothing
	Private Picture1 As Picture = Nothing
	Private Label1 As Label = Nothing
	Private LabelCaption As Label = Nothing
	Private field As TextBox = Nothing
	Private LabelPage As Label = Nothing
	Public Sub InitializeReport()
		Me.LoadLayout(Me.GetType, "ARNETCrosstab.rptCrossTab.rpx")
		Me.PageHeader = CType(Me.Sections("PageHeader"),DataDynamics.ActiveReports.PageHeader)
		Me.Detail = CType(Me.Sections("Detail"),DataDynamics.ActiveReports.Detail)
		Me.PageFooter = CType(Me.Sections("PageFooter"),DataDynamics.ActiveReports.PageFooter)
		Me.Picture1 = CType(Me.PageHeader.Controls(0),DataDynamics.ActiveReports.Picture)
		Me.Label1 = CType(Me.PageHeader.Controls(1),DataDynamics.ActiveReports.Label)
		Me.LabelCaption = CType(Me.PageHeader.Controls(2),DataDynamics.ActiveReports.Label)
		Me.field = CType(Me.Detail.Controls(0),DataDynamics.ActiveReports.TextBox)
		Me.LabelPage = CType(Me.PageFooter.Controls(0),DataDynamics.ActiveReports.Label)
	End Sub

	#End Region

    Dim nPage As Integer
    Dim nWidth As Integer

    Private Sub rptCrossTab_ReportStart(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.ReportStart

        ' Declare Data Source
        Dim oDs = New DataDynamics.ActiveReports.DataSources.OleDBDataSource()

        ' SQL Statement
        Dim cSQL As String

        Dim iLoop As Integer                    ' Loop counter
        Dim nLeft As Integer                    ' Left Parameter
        Dim nFields As Integer

        ' Build Connection String
        oDs.ConnectionString = "Provider=SQLOLEDB;User ID=sa;password=poptart;Initial Catalog=Northwind;Data Source=VIVID_VIAO;"

        ' Set Error Trap
        On Error GoTo OpenConnectionError

        ' Set Page Number
        If nPage = 0 Then
            nPage = 1
        End If

        ' Get Print Width
        nWidth = Me.PrintWidth

        '-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        '
        ' Build the CrossTab SQL.
        '
        ' NOTE : In this CrossTab SQL Example I'm using the Orders Table in
        '        the Northwind database to sum the freight charges for each of
        '        the 18 months accross the top (starting from July 96) while
        '        representing the Product Name in the first column (row header)
        '        for a 18 month period, which results in 20 columns (1 for Totals,
        '        another for the customer name + 18 months)
        '
        '-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

        cSQL = "SELECT p.ProductName, "

        ' -- All Orders from July 1996
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '7/1/1996' AND '7/31/1996' THEN Freight ELSE 0 END) As July96,"
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '8/1/1996' AND '8/31/1996' THEN Freight ELSE 0 END) As Aug96,"
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '9/1/1996' AND '9/30/1996' THEN Freight ELSE 0 END) As Sep96,"
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '10/1/1996' AND '10/31/1996' THEN Freight ELSE 0 END) As Oct96,"
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '11/1/1996' AND '11/30/1996' THEN Freight ELSE 0 END) As Nov96,"
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '12/1/1996' AND '12/31/1996' THEN Freight ELSE 0 END) As Dec96,"

        ' -- All Orders for 1997
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '1/1/1997' AND '1/31/1997' THEN Freight ELSE 0 END) As Jan97,"
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '2/1/1997' AND '2/28/1997' THEN Freight ELSE 0 END) As Feb96,"
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '3/1/1997' AND '3/31/1997' THEN Freight ELSE 0 END) As Mar97,"
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '4/1/1997' AND '4/30/1997' THEN Freight ELSE 0 END) As Apr97,"
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '5/1/1997' AND '5/31/1997' THEN Freight ELSE 0 END) As May96,"
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '6/1/1997' AND '6/30/1997' THEN Freight ELSE 0 END) As June97,"
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '7/1/1997' AND '7/31/1997' THEN Freight ELSE 0 END) As July97,"
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '8/1/1997' AND '8/31/1997' THEN Freight ELSE 0 END) As Aug97,"
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '9/1/1997' AND '9/30/1997' THEN Freight ELSE 0 END) As Sep97,"
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '10/1/1997' AND '10/31/1997' THEN Freight ELSE 0 END) As Oct97,"
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '11/1/1997' AND '11/30/1997' THEN Freight ELSE 0 END) As Nov97,"
        cSQL = cSQL & "SUM(CASE WHEN OrderDate BETWEEN '12/1/1997' AND '12/31/1997' THEN Freight ELSE 0 END) As Dec97 "

        ' Order and Grouping
        cSQL = cSQL & "FROM Orders o, [Order Details] d, Products p "
        cSQL = cSQL & "WHERE o.OrderID = d.OrderID "
        cSQL = cSQL & "AND d.ProductID = p.ProductID "
        cSQL = cSQL & "GROUP BY p.ProductName"

        ' Assign SQL Back to Data Source
        oDs.SQL = cSQL

        ' Open Data Source
        Me.DataSource = oDs

        On Error GoTo Trap

        nLeft = 0.63 ' Offset of Base Label

        ' Get First Label Contents
        LabelCaption.Text = "Product"

        ' Get First Data Field
        Me.field.DataField = "ProductName"

        ' Create the Labels across the top
        nFields = Me.Fields.Count

        For iLoop = 1 To nFields - 1
            ' Increment Position
            nLeft = nLeft + 0.75

            ' Update Print Width
            ' Adjust Width by one field and Margin
            nWidth = nWidth + (0.75 + Me.PageSettings.Margins.Left)

            ' Update Print Width
            Me.PrintWidth = nWidth

            ' Add Labels
            AddLabel(Me.Fields(iLoop).Name, nLeft, "Lbl" & iLoop)

            ' Add Field
            AddField(Me.Fields(iLoop).Name, nLeft, "fld" & iLoop)

        Next iLoop

        ' Adjust Left
        nLeft = nLeft + 0.75

        ' Add Total Label
        AddLabel("Total", nLeft, "LabelTotal")

        ' Add Field
        AddField("", nLeft, "fieldTotal")

Exit_Rtn:
        Exit Sub

OpenConnectionError:
        MsgBox("Unable to Open Database Connection!", vbExclamation, "Error")
        GoTo Exit_Rtn

Trap:
        MsgBox("A System Error Has Occurred!" & vbCrLf & _
            Err.Description & vbCrLf & _
            "Error Code = " & Err.Number, vbExclamation, "Error")

        GoTo Exit_Rtn

    End Sub



    Private Sub AddLabel(ByVal cCaption As String, ByVal nLeft As Integer, Optional ByVal cName As String = "")

        '
        ' This Subroutine Dynamically creates a Label at Runtime.
        ' To Call this Function :
        '
        '   AddLabel("LabelName", 1.53, "LabelHeader1")
        '
        Dim oLabel As DataDynamics.ActiveReports.Label = New DataDynamics.ActiveReports.Label() ' Label Object

        Me.PageHeader.Controls.Add(oLabel)

        With oLabel
            .Text = cCaption

            ' Set Label Position, Alignment and other properties
            .Left = nLeft
            .Top = Me.LabelCaption.Top
            .Height = Me.LabelCaption.Height
            .Width = 0.75

            '.BackStyle = Me.LabelCaption.BackStyle
            .BackColor = Me.LabelCaption.BackColor
            .Alignment = Me.LabelCaption.Alignment

            If cName <> vbNullString Then
                .Name = cName
            End If

            .Visible = True
        End With

    End Sub

    Private Sub AddField(ByVal cField As String, ByVal nLeft As Integer, Optional ByVal cName As String = "")

        Dim oField As DataDynamics.ActiveReports.TextBox = New DataDynamics.ActiveReports.TextBox()

        ' Create the Fields
        Me.Detail.Controls.Add(oField)

        ' Set Field, Position, and other properties
        With oField
            .DataField = cField

            .Left = nLeft
            .Top = Me.field.Top
            .Height = Me.field.Height
            .Width = 0.75

            .OutputFormat = Me.field.OutputFormat
            .Alignment = TextAlignment.Right 'Me.field.Alignment

            If cName <> vbNullString Then
                .Name = cName
            End If

            .Visible = True
        End With

    End Sub

    Private Sub Detail_Format(ByVal sender As Object, ByVal e As System.EventArgs) Handles Detail.Format
        Dim iLoop As Integer        ' Loop Counter
        Dim nTotal As Double         ' Row Total
        Dim oFld As DataDynamics.ActiveReports.TextBox

        oFld = Me.Detail.Controls("fieldTotal")
        nTotal = 0

        ' Sum this Row
        For iLoop = 1 To (Me.Fields.Count - 1)
            nTotal = nTotal + Me.Fields(iLoop).Value
        Next iLoop

        ' Set the Total for these Columns
        oFld.Text = Format(nTotal, "$#,###.00")
    End Sub

    Private Sub PageFooter_Format(ByVal sender As Object, ByVal e As System.EventArgs) Handles PageFooter.Format
        ' Display Page Number
        Me.LabelPage.Text = "Page : " & CStr(nPage)

        ' Increment Page Count
        nPage = nPage + 1
    End Sub
End Class

