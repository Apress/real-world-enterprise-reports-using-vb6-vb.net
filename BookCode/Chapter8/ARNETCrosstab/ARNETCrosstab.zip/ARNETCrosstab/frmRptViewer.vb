Public Class frmRptViewer
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer


    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private WithEvents Viewer1 As DataDynamics.ActiveReports.Viewer.Viewer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Viewer1 = New DataDynamics.ActiveReports.Viewer.Viewer()
        Me.SuspendLayout()
        '
        'Viewer1
        '
        Me.Viewer1.BackColor = System.Drawing.SystemColors.Control
        Me.Viewer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Viewer1.Name = "Viewer1"
        Me.Viewer1.ReportViewer.CurrentPage = 0
        Me.Viewer1.ReportViewer.MultiplePageCols = 3
        Me.Viewer1.ReportViewer.MultiplePageRows = 2
        Me.Viewer1.Size = New System.Drawing.Size(944, 622)
        Me.Viewer1.TabIndex = 0
        Me.Viewer1.TableOfContents.Text = "Contents"
        Me.Viewer1.TableOfContents.Width = 200
        Me.Viewer1.Toolbar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'StartForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(944, 622)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Viewer1})
        Me.MaximumSize = New System.Drawing.Size(1096, 656)
        Me.Name = "StartForm"
        Me.Text = "Product Weekly Sales"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmRptViewer_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Show the Form
        Me.Show()

        ' Declare the Report
        Dim rpt = New rptCrossTab()

        ' Set the Viewer document to the report
        Me.Viewer1.Document = rpt.Document

        ' Run the report
        rpt.Run(True)
    End Sub

End Class
