Imports System.Text

Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel

    Dim objListBoxLabelColl As New Collection()
    Dim objListBoxColl As New Collection()
    Dim objListBoxButtonColl As New Collection()

    Dim objComboBoxLabelColl As New Collection()
    Dim objComboBoxColl As New Collection()

    Dim objDateRangeLabelColl As New Collection()
    Dim objDateFromColl As New Collection()
    Dim objDateToColl As New Collection()

    Dim objCheckBoxColl As New Collection()

    Const SELECT_PRODUCT = 1
    Const SELECT_SOURCE = 2

    Const SELECT_ENTER_DATE = 1
    Const SELECT_RECEIVE_DATE = 2

    Const SELECT_FIRST_NAME = 1
    Const SELECT_LAST_NAME = 2

    Const SELECT_DEPARTMENT = 1

    Const SELECT_COMPLEX_QUESTION = 1

    Const BOOL_TRUE = -1
    Const BOOL_FALSE = 0

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, _
        ByVal e As System.EventArgs) Handles MyBase.Init

        InitializeComponent()

    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, _
        ByVal e As System.EventArgs) Handles MyBase.Load

        Dim oConn As New OleDb.OleDbConnection()
        Dim objDR As OleDb.OleDbDataReader
        Dim cConnectString As String

        'Connect to data source
        cConnectString = "Provider=Microsoft.Jet.OLEDB.4.0;" & _
        "Data Source=C:\\BookCode\\SampleDatabase.mdb"

        oConn.ConnectionString = cConnectString
        oConn.Open()

        'Invoke routines which display web controls
        ShowDateRange(SELECT_ENTER_DATE, 8, 32, 20, "Enter Date:")
        ShowCheckBox(SELECT_COMPLEX_QUESTION, 8, 95, 20, "Complex Question")
        ShowComboBox(SELECT_DEPARTMENT, 8, 140, 180, 20, "Department")
        ShowListBox(SELECT_PRODUCT, 8, 200, 180, 20, "Product")
        ShowListBox(SELECT_SOURCE, 200, 200, 180, 20, "Source")

        'Populate data bound web controls (list and combo boxes) with data
        If Not Page.IsPostBack Then
            LoadTable(oConn, objComboBoxColl(SELECT_DEPARTMENT), _
                "Department", "ID", "Descr")
            LoadTable(oConn, objListBoxColl(SELECT_PRODUCT), _
                "Product", "ID", "Descr")
            LoadTable(oConn, objListBoxColl(SELECT_SOURCE), _
                "Source", "ID", "Descr")
        End If

        PositionButtons()

    End Sub 'Page_Load  

    Sub PositionButtons()
        cmdOK.Style("position") = "absolute"
        cmdOK.Style("left") = Panel1.Width.Value - cmdOK.Width.Value - 10 & "px"
        cmdOK.Style("top") = "10px"

        cmdCancel.Style("position") = "absolute"
        cmdCancel.Style("left") = Panel1.Width.Value - cmdOK.Width.Value - 10 & "px"
        cmdCancel.Style("top") = "50px"

    End Sub

    Private Sub ShowListBox(ByVal iIndex As Short, ByVal iLeft As Short, _
        ByVal iTop As Short, ByVal iWidth As Short, ByVal iHeight As Short, _
        ByVal cCaption As String)

        Dim iListBoxHeight As Short

        Call AddDynamicListBoxLabel(iIndex, iLeft, iTop, iWidth, cCaption)

        Call AddDynamicListBox(iIndex, iLeft, iTop + iHeight + 5, iWidth, 180)

        iListBoxHeight = Replace(objListBoxColl(iIndex).style("height"), "px", String.Empty)

        Call AddDynamicListBoxButton(iIndex, iLeft, (iTop + iHeight + 5) + _
             iListBoxHeight + 5, iWidth, cCaption)

    End Sub

    Private Sub objListBox_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim objListbox As ListBox
        Dim objButton As Button
        Dim iIndex As Integer

        For Each objButton In objListBoxButtonColl

            iIndex += 1

            If objButton Is sender Then
                Exit For
            End If

        Next

        objListbox = CType(objListBoxColl(iIndex), ListBox)

        objListbox.ClearSelection()

    End Sub

    Private Sub AddDynamicListBoxLabel(ByVal iIndex As Short, ByVal iLeft As Short, _
    ByVal iTop As Short, ByVal iWidth As Short, ByVal cCaption As String)

        Dim objLabel As New Label()

        With objLabel
            .Style("position") = "absolute"
            .Style("left") = iLeft & "px"
            .Style("top") = iTop & "px"
            .Text = cCaption
        End With

        objListBoxLabelColl.Add(objLabel)

        Panel1.Controls.Add(objLabel)

    End Sub

    Private Sub AddDynamicListBox(ByVal iIndex As Short, ByVal iLeft As Short, _
        ByVal iTop As Short, ByVal iWidth As Short, ByVal iHeight As Short)

        Dim objListBox As New ListBox()

        With objListBox
            .Style("position") = "absolute"
            .Style("left") = iLeft & "px"
            .Style("top") = iTop & "px"
            .Style("height") = iHeight & "px"
            .Style("width") = iWidth & "px"
            .SelectionMode = ListSelectionMode.Multiple
        End With

        objListBoxColl.Add(objListBox)

        Panel1.Controls.Add(objListBox)

    End Sub

    Private Sub AddDynamicListBoxButton(ByVal iIndex As Short, ByVal iLeft As Short, _
        ByVal iTop As Short, ByVal iWidth As Short, ByVal cCaption As String)

        Dim objButton As New Button()

        With objButton
            .Style("position") = "absolute"
            .Style("left") = iLeft & "px"
            .Style("top") = iTop & "px"
            .Style("width") = iWidth & "px"
            .Text = "Clear Selected " & cCaption
        End With

        objButton = CType(objButton, Button)

        AddHandler objButton.Click, AddressOf objListBox_Click

        objListBoxButtonColl.Add(objButton)

        Panel1.Controls.Add(objButton)

    End Sub

    Private Sub ShowComboBox(ByVal iIndex As Short, ByVal iLeft As Short, _
    ByVal iTop As Short, ByVal iWidth As Short, ByVal iHeight As Short, _
    ByVal cCaption As String)

        Call AddDynamicComboBoxLabel(iIndex, iLeft, iTop, iWidth, iHeight, cCaption)

        Call AddDynamicComboBox(iIndex, 200, iTop, iWidth, iHeight)

    End Sub

    Private Sub AddDynamicComboBoxLabel(ByVal iIndex As Short, ByVal iLeft As Short, _
        ByVal iTop As Short, ByVal iWidth As Short, ByVal iHeight As Short, _
        ByVal cCaption As String)

        Dim objLabel As New Label()

        With objLabel
            .Height = Unit.Pixel(iHeight)
            .Style("position") = "absolute"
            .Style("left") = iLeft & "px"
            .Style("top") = iTop & "px"
            .Text = cCaption
        End With

        objComboBoxLabelColl.Add(objLabel)

        Panel1.Controls.Add(objLabel)

    End Sub

    Private Sub AddDynamicComboBox(ByVal iIndex As Short, ByVal iLeft As Short, _
        ByVal iTop As Short, ByVal iWidth As Short, ByVal iHeight As Short)

        Dim objCombobox As New DropDownList()

        With objCombobox
            .Style("position") = "absolute"
            .Style("left") = iLeft & "px"
            .Style("top") = iTop & "px"
        End With

        objComboBoxColl.Add(objCombobox)

        Panel1.Controls.Add(objCombobox)

    End Sub

    Private Sub ShowDateRange(ByVal iIndex As Short, ByVal iLeft As Short, _
        ByVal iTop As Short, ByVal iHeight As Short, ByVal cCaption As String)

        Call AddDynamicDateRangeLabel(iIndex, iLeft, iTop, iHeight, cCaption)

        Call AddDynamicDateFrom(iIndex, iLeft + 100, iTop, iHeight)

        Call AddDynamicDateTo(iIndex, iLeft + 300, iTop, iHeight)

    End Sub

    Private Sub AddDynamicDateRangeLabel(ByVal iIndex As Short, ByVal iLeft As Short, _
        ByVal iTop As Short, ByVal iHeight As Short, ByVal cCaption As String)

        Dim objLabel As New Label()

        With objLabel
            .Height = Unit.Pixel(iHeight)
            .Style("position") = "absolute"
            .Style("left") = iLeft & "px"
            .Style("top") = iTop & "px"
            .Text = cCaption
        End With

        objDateRangeLabelColl.Add(objLabel)

        Panel1.Controls.Add(objLabel)

    End Sub

    Private Sub AddDynamicDateFrom(ByVal iIndex As Short, ByVal iLeft As Short, _
        ByVal iTop As Short, ByVal iHeight As Short)

        Dim objTextBox As New TextBox()

        With objTextBox
            .Style("position") = "absolute"
            .Style("left") = iLeft & "px"
            .Style("top") = iTop & "px"
            .Style("width") = "120px"
        End With

        objDateFromColl.Add(objTextBox)

        Panel1.Controls.Add(objTextBox)

    End Sub

    Private Sub AddDynamicDateTo(ByVal iIndex As Short, ByVal iLeft As Short, _
        ByVal iTop As Short, ByVal iHeight As Short)

        Dim objTextBox As New TextBox()

        With objTextBox
            .Style("position") = "absolute"
            .Style("left") = iLeft & "px"
            .Style("top") = iTop & "px"
            .Style("width") = "120px"
        End With

        objDateToColl.Add(objTextBox)

        Panel1.Controls.Add(objTextBox)

    End Sub


    Private Sub ShowCheckBox(ByVal iIndex As Short, ByVal iLeft As Short, _
    ByVal iTop As Short, ByVal iHeight As Short, ByVal cCaption As String)

        Call AddDynamicCheckBox(iIndex, iLeft, iTop, iHeight, cCaption)

    End Sub

    Private Sub AddDynamicCheckBox(ByVal iIndex As Short, ByVal iLeft As Short, _
        ByVal iTop As Short, ByVal iHeight As Short, ByVal cCaption As String)

        Dim objCheckBox As New CheckBox()

        With objCheckBox
            .Style("position") = "absolute"
            .Style("left") = iLeft & "px"
            .Style("top") = iTop & "px"
            .Text = cCaption
            .Height = Unit.Pixel(iHeight)
        End With

        objCheckBoxColl.Add(objCheckBox)

        Panel1.Controls.Add(objCheckBox)

    End Sub

    Sub LoadTable(ByVal oConn As OleDb.OleDbConnection, ByRef oControl As Object, _
    ByVal cTable As String, ByVal cID As String, ByVal cDescr As String)

        Dim oDS As New DataSet()
        Dim oDA As OleDb.OleDbDataAdapter
        Dim cSQL As String

        cSQL = "SELECT " & cID & ", " & cDescr & _
               " FROM " & cTable & _
               " ORDER BY " & cDescr

        oDA = New OleDb.OleDbDataAdapter(cSQL, oConn)
        oDA.Fill(oDS, cTable)

        With oControl
            .DataSource = oDS.Tables(0)
            .DataTextField = cDescr
            .DataValueField = cID
            .DataBind()
        End With

    End Sub

    Protected WithEvents cmdCancel As System.Web.UI.WebControls.Button
    Protected WithEvents cmdOK As System.Web.UI.WebControls.Button

    Private Sub cmdOK_Click(ByVal sender As System.Object, _
        ByVal e As System.EventArgs) Handles cmdOK.Click

        Dim objSQL As New StringBuilder()
        Dim cSQL As String
        Dim objCriteria As New StringBuilder()
        Dim cCriteria As String
        Dim cDateFrom As String
        Dim cDateTo As String

        cDateFrom = objDateFromColl(SELECT_ENTER_DATE).Text
        cDateTo = objDateToColl(SELECT_ENTER_DATE).Text

        With objSQL
            .AppendFormat(GetDateSQL("createdate", cDateFrom, cDateTo))
            .AppendFormat(GetListBoxSQL(objListBoxColl(SELECT_PRODUCT), "ProductID"))
            .AppendFormat(GetListBoxSQL(objListBoxColl(SELECT_SOURCE), "SourceID"))
            .AppendFormat(GetComboBoxSQL(SELECT_DEPARTMENT, "deptid"))
            .AppendFormat(GetCheckBoxSQL(SELECT_COMPLEX_QUESTION, "questiontype"))
        End With

        With objCriteria
            .AppendFormat(GetDateCriteria("createdate", cDateFrom, cDateTo))
            .AppendFormat(GetListBoxCriteria(objListBoxColl(SELECT_PRODUCT), "Product"))
            .AppendFormat(GetListBoxCriteria(objListBoxColl(SELECT_SOURCE), "Source"))
            .AppendFormat(GetComboBoxCriteria(SELECT_DEPARTMENT, "Department"))
            .AppendFormat(GetCheckBoxCriteria(SELECT_COMPLEX_QUESTION, "Complex Question"))
        End With

        cSQL = objSQL.ToString
        cCriteria = objCriteria.ToString

        If objSQL.ToString <> String.Empty Then
            cSQL = cSQL.Substring(0, cSQL.Length - 5)
        End If

        If objCriteria.ToString <> String.Empty Then
            cCriteria = cCriteria.Substring(0, cCriteria.Length - 5)
        End If

    End Sub

    Function GetDateSQL(ByVal cFieldName As String, ByVal cDateFrom As String, _
        ByVal cDateTo As String) As String
        Dim cSQL As String = String.Empty

        If IsDate(cDateFrom) And IsDate(cDateTo) Then

            cSQL = cFieldName & " BETWEEN " & Chr(39) & cDateFrom & Chr(39) & _
                " AND " & Chr(39) & cDateTo & Chr(39) & " AND "

        End If

        Return cSQL

    End Function

    Function GetDateCriteria(ByVal cDescr As String, ByVal cDateFrom As String, _
        ByVal cDateTo As String) As String
        Dim cResult As String = String.Empty

        If IsDate(cDateFrom) And IsDate(cDateTo) Then

            cResult = cResult & "the " & cDescr & " is between " & cDateFrom & _
                " and " & cDateTo & " and " & vbCrLf

        End If

        Return cResult

    End Function

    Function GetCheckBoxSQL(ByVal iIndex As Integer, _
        ByVal cColumn As String) As String

        Dim cSQL As String = String.Empty

        Select Case objCheckBoxColl(iIndex).Checked

            Case True
                cSQL = cColumn & " = " & BOOL_TRUE & " AND "

            Case False
                cSQL = cColumn & " = " & BOOL_FALSE & " AND "

        End Select

        GetCheckBoxSQL = cSQL

    End Function

    Function GetCheckBoxCriteria(ByVal iIndex As Integer, _
        ByVal cDescr As String) As String

        Dim cResult As String = String.Empty

        Select Case objCheckBoxColl(iIndex).Checked

            Case True
                cResult = "the " & cDescr & " is True and "

            Case False
                cResult = "the " & cDescr & " is False and "

        End Select

        GetCheckBoxCriteria = cResult

    End Function

    Function GetComboBoxSQL(ByVal Index As Integer, _
        ByVal cColumn As String) As String

        Dim cSQL As String = String.Empty
        Dim lChoiceID As Long

        lChoiceID = objComboBoxColl(Index).SelectedItem.Value

        If lChoiceID > 0 Then

            cSQL = cColumn & " = " & lChoiceID & " AND "

        End If

        GetComboBoxSQL = cSQL

    End Function

    Function GetComboBoxCriteria(ByVal Index As Integer, _
        ByVal cDescr As String) As String

        Dim cResult As String = String.Empty
        Dim cChoice As String

        cChoice = objComboBoxColl(Index).SelectedItem.Text

        If cChoice <> String.Empty Then

            cResult = "the " & cDescr & " is " & cChoice & " and "

        End If

        GetComboBoxCriteria = cResult

    End Function


    Function GetListBoxSQL(ByRef objListBox As ListBox, _
        ByVal cColumn As String) As String

        Dim cSQL As String = String.Empty
        Dim cList As String

        cList = ParseIt(objListBox, True, False, 0)

        If cList <> String.Empty Then
            cSQL = cColumn & " IN " & cList & " AND "
        End If

        GetListBoxSQL = cSQL

    End Function

    Function GetListBoxCriteria(ByRef objListBox As ListBox, _
        ByVal cDescr As String) As String

        Dim cResult As String = String.Empty
        Dim cNames As String

        cNames = ParseIt(objListBox, True, False, 1)

        If cNames <> String.Empty Then

            cResult = cResult & "the " & cDescr & " is among " & cNames & " and " & vbCrLf

        End If

        GetListBoxCriteria = cResult

    End Function

    Function ParseIt(ByVal oList As ListBox, ByVal bTagged As Boolean, _
        ByVal bQuotes As Boolean, ByVal iCol As Short) As String

        Dim objResult As New StringBuilder("(")
        Dim cResult As String = String.Empty
        Dim cQuotes As String
        Dim cData As String
        Dim oTemp As ListItem
        Dim oCollection As Object

        If bQuotes Then
            cQuotes = ControlChars.Quote
        Else
            cQuotes = String.Empty
        End If

        If bTagged Then

            For Each oTemp In oList.Items

                If oTemp.Selected Then

                    If iCol = 0 Then
                        cData = oTemp.Value
                    Else
                        cData = oTemp.Text
                    End If

                    objResult.AppendFormat(cQuotes & cData & cQuotes & ",")

                End If

            Next

        Else

            For Each oTemp In oList.Items

                If iCol = 0 Then
                    cData = oTemp.Value
                Else
                    cData = oTemp.Text
                End If

                objResult.AppendFormat(cQuotes & cData & cQuotes & ",")

            Next

        End If

        cResult = objResult.ToString

        If bQuotes Then
            cResult = Mid$(cResult, 1, Len(cResult) - 2) & cQuotes & ")"
        Else
            cResult = Mid$(cResult, 1, Len(cResult)) & cQuotes & ")"
        End If

        cResult = Replace(cResult, ",)", ")")

        cResult = Replace(cResult, ",,", String.Empty)

        If cResult = "()" Then
            cResult = String.Empty
        End If

        ParseIt = cResult

    End Function

End Class
